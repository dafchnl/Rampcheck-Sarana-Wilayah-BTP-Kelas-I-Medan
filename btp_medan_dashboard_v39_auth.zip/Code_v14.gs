/**
 * BTP MEDAN — RAMPCHECK DASHBOARD BACKEND (Google Apps Script) — v13
 * ===================================================================
 * STRUKTUR DATABASE:
 *   - "Lokomotif" / "Kereta" / "KRD" / "Gerbong" : log lengkap tiap rampcheck
 *   - "REKAP"        : 1 baris per Nomor Sarana = status terkini (upsert)
 *   - "Rekap Temuan" : 1 baris per TEMUAN, TIDAK PERNAH DITIMPA.
 *   - "Detail Checklist" : 1 baris per rampcheck (Nomor Sarana + Tanggal),
 *                      menyimpan seluruh isi checklist + link checksheet.
 *   - "Dokumen PM"   : 1 baris per DOKUMEN (regulasi/sertifikasi/checksheet/
 *                      laporan) yang diupload dari menu "Dokumen PM & Regulasi".
 *   - "Data Lainnya" : cadangan kalau jenis sarana tak dikenali
 *
 * PERUBAHAN v13 (menggabungkan autentikasi akun dengan pola koneksi database v10) (dari v9) — PERBAIKAN BUG FOTO TEMUAN HILANG:
 *   Sebelumnya, di _uploadPhotosToDrive, baris file.setSharing(...) dan
 *   baris yang membuat link foto (urls.push) berada di dalam try/catch
 *   YANG SAMA. Kalau setSharing() gagal — misalnya karena kebijakan Google
 *   Workspace organisasi (akun instansi/Kemenhub) melarang "bagikan ke
 *   siapa saja di internet" — maka baris urls.push ikut batal dieksekusi,
 *   sehingga foto itu TIDAK PERNAH mendapat link sama sekali. Ini sebab
 *   utama kenapa foto bukti temuan sering hilang/tidak tampil, terutama
 *   setelah refresh (karena hanya link foto yang disimpan ke cache lokal,
 *   dan kalau link itu tidak pernah terbuat, tidak ada yang tersisa untuk
 *   ditampilkan).
 *   PERBAIKAN: setSharing() sekarang dipisah ke try/catch sendiri, jadi
 *   kalaupun gagal dibagikan publik, link foto tetap dibuat (dan foto akan
 *   tetap bisa diakses oleh sesama akun di domain organisasi, atau kalau
 *   folder Drive-nya sendiri sudah diatur sharing-nya secara manual).
 *   Format URL foto juga diganti dari "thumbnail?id=...&sz=w1600" menjadi
 *   "uc?export=view&id=..." yang lebih standar dan stabil untuk dipakai
 *   sebagai src gambar di browser.
 *
 * CATATAN PENTING SETELAH DEPLOY:
 *   Kalau Google Drive organisasi Anda memang membatasi "berbagi ke luar
 *   organisasi", foto yang lama (yang sudah kadung gagal dapat link) TIDAK
 *   akan otomatis punya link — itu hanya berlaku untuk foto BARU yang
 *   diupload setelah v10 ini di-deploy. Kalau perlu, foto lama bisa
 *   diperbaiki manual dari folder Drive "Rampcheck - Bukti Foto".
 */

var SHEET_REKAP    = 'REKAP';
var SHEET_TEMUAN   = 'Rekap Temuan';
var SHEET_DOKUMEN  = 'Dokumen PM';
var SHEET_SERTIF   = 'Sertifikasi Links';
var SHEET_DETAIL   = 'Detail Checklist';
var SHEET_FALLBACK = 'Data Lainnya';
var TYPE_SHEETS    = ['Lokomotif','Kereta','KRD','Gerbong'];
var DRIVE_FOLDER   = 'Rampcheck - Bukti Foto';
var DRIVE_FOLDER_DOKUMEN = 'Rampcheck - Dokumen PM';
var DRIVE_FOLDER_CHECKSHEET = 'Rampcheck - Checksheet Resmi';

var KEMENHUB_LOGO_B64 = 'PASTE_KEMENHUB_LOGO_B64_DARI_FILE_LAMA_DI_SINI';

var TEMUAN_HEADERS = ['ID Temuan','Nomor Sarana','Tanggal','Jenis Sarana','Level',
  'Komponen/Seksi','Item Temuan','Standar','Catatan','Foto Bukti','Status Temuan',
  'Riwayat Update','Tanggal Update Terakhir','Waktu Kirim'];

var DOKUMEN_HEADERS = ['ID Dokumen','Nama File','Kategori','Ukuran (bytes)',
  'URL File','Tanggal Upload','Diupload Oleh'];

var SERTIF_HEADERS = ['ID Layanan','URL','Tanggal Update'];

var DETAIL_HEADERS = ['Kunci','Nomor Sarana','Tanggal','Jenis Sarana','Depo',
  'Lokasi Pemeriksaan','Link Checksheet','Full Checklist JSON','Full Wheels JSON',
  'Temuan JSON','Waktu Kirim'];

function _sheet(name){
  var ss = SpreadsheetApp.getActiveSpreadsheet();
  var sh = ss.getSheetByName(name);
  if(!sh) sh = ss.insertSheet(name);
  return sh;
}
function _json(obj){
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

function _headerRowIndex(sh){
  var maxCheck = Math.min(10, Math.max(sh.getLastRow(),1));
  var lastCol = Math.max(sh.getLastColumn(),1);
  for(var r=1;r<=maxCheck;r++){
    var vals = sh.getRange(r,1,1,lastCol).getValues()[0];
    for(var c=0;c<vals.length;c++){
      if(String(vals[c]||'').replace(/\n/g,' ').trim().toUpperCase()==='NOMOR SARANA') return r;
    }
  }
  for(var r2=1;r2<=maxCheck;r2++){
    var vals2 = sh.getRange(r2,1,1,lastCol).getValues()[0];
    var filled = vals2.filter(function(v){ return v!==null && String(v).trim()!==''; }).length;
    if(filled>=3) return r2;
  }
  return 1;
}

/** Unggah array base64 (data:image/...;base64,xxxx) ke folder Drive, kembalikan array URL.
 *  v10: setSharing() dipisah dari pembuatan link supaya kegagalan izin-berbagi
 *  (kebijakan domain organisasi) tidak ikut menggagalkan link fotonya. */
function _uploadPhotosToDrive(base64Arr, prefix){
  if(!base64Arr || !base64Arr.length) return [];
  var folders = DriveApp.getFoldersByName(DRIVE_FOLDER);
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(DRIVE_FOLDER);
  var urls=[];
  base64Arr.forEach(function(b64, idx){
    var file;
    try{
      var m = String(b64).match(/^data:(image\/[a-zA-Z0-9.+-]+);base64,(.*)$/);
      if(!m) return;
      var mime=m[1], data=m[2];
      var blob = Utilities.newBlob(Utilities.base64Decode(data), mime, prefix+'_'+idx+'_'+new Date().getTime()+'.jpg');
      file = folder.createFile(blob);
    } catch(uploadErr){
      /* Gagal total mengunggah foto ini (data rusak dsb) — lewati saja,
         jangan gagalkan foto lain atau seluruh proses simpan. */
      return;
    }
    /* Coba bagikan publik. Kalau kebijakan Workspace organisasi melarang
       "berbagi ke luar organisasi", panggilan ini akan melempar error —
       DIPISAH supaya tidak ikut membatalkan pembuatan link di bawah. */
    try{
      file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW);
    } catch(shareErr){
      /* Lanjut saja. Link tetap dibuat; kalau folder induknya sudah
         dibagikan manual (atau viewer sesama akun domain), foto tetap
         bisa terbuka. Kalau tidak, minimal filenya tetap tersimpan aman
         di Drive dan bisa dibuka manual oleh pemilik akun. */
    }
    urls.push('https://drive.google.com/uc?export=view&id='+file.getId());
  });
  return urls;
}

/** Unggah SATU file apa pun (PDF/DOCX/XLSX/JPG/dst) ke folder Dokumen PM di Drive. */
function _uploadFileToDrive(dataUrl, filename){
  var m = String(dataUrl).match(/^data:([^;]+);base64,(.*)$/);
  if(!m) throw new Error('Format file tidak valid (bukan data URL base64)');
  var mime = m[1], data = m[2];
  var folders = DriveApp.getFoldersByName(DRIVE_FOLDER_DOKUMEN);
  var folder = folders.hasNext() ? folders.next() : DriveApp.createFolder(DRIVE_FOLDER_DOKUMEN);
  var blob = Utilities.newBlob(Utilities.base64Decode(data), mime, filename);
  var file = folder.createFile(blob);
  try{ file.setSharing(DriveApp.Access.ANYONE_WITH_LINK, DriveApp.Permission.VIEW); } catch(shareErr){}
  return {
    id: file.getId(),
    url: 'https://drive.google.com/file/d/'+file.getId()+'/view',
    downloadUrl: 'https://drive.google.com/uc?export=download&id='+file.getId()
  };
}

function _ensureDokumenHeader(){
  var sh=_sheet(SHEET_DOKUMEN);
  if(sh.getLastRow()<1){ sh.getRange(1,1,1,DOKUMEN_HEADERS.length).setValues([DOKUMEN_HEADERS]); }
  return sh;
}
function _ensureSertifHeader(){
  var sh=_sheet(SHEET_SERTIF);
  if(sh.getLastRow()<1){ sh.getRange(1,1,1,SERTIF_HEADERS.length).setValues([SERTIF_HEADERS]); }
  return sh;
}
function _ensureDetailHeader(){
  var sh=_sheet(SHEET_DETAIL);
  if(sh.getLastRow()<1){
    sh.getRange(1,1,1,DETAIL_HEADERS.length).setValues([DETAIL_HEADERS]);
    return sh;
  }
  var headers=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getValues()[0].map(String);
  var missing=DETAIL_HEADERS.filter(function(h){ return headers.indexOf(h)===-1; });
  if(missing.length){ sh.getRange(1, headers.length+1, 1, missing.length).setValues([missing]); }
  return sh;
}

function _esc(s){
  return String(s==null?'':s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
}
function _hasilMark(v){
  if(v==='ok') return '<span style="color:#000;font-weight:700">&#10003;</span>';
  if(v==='ng') return '<span style="color:#000;font-weight:700">&#10007;</span>';
  if(v==='na') return '<span style="color:#000">&ndash;</span>';
  return '';
}

function _buildChecksheetHtml(entry){
  var fullChecklist = entry.fullChecklist || [];
  var fullWheels = entry.fullWheels || {};
  var temuan = entry.temuan || [];
  var rows='', no=1;
  fullChecklist.forEach(function(sec){
    var secTitle=String(sec.sec||'').replace(/^\d+\.\s*/,'');
    rows+='<tr style="background:#F1F5F9"><td style="text-align:center;font-weight:700;padding:5px 6px">'+no+'</td>'+
      '<td colspan="2" style="font-weight:700;padding:5px 6px">'+_esc(secTitle)+'</td>'+
      (sec.k2?'<td style="text-align:center;font-weight:700;padding:5px 6px">Kabin-1</td><td style="text-align:center;font-weight:700;padding:5px 6px">Kabin-2</td>':'<td colspan="2"></td>')+
    '</tr>';
    no++;
    (sec.items||[]).forEach(function(it){
      var lbl=_esc(it.lbl);
      var stdCell='<td style="padding:4px 6px;color:#000">'+_esc(it.std)+(it.psi&&it.psiVal?' <br><span style="font-size:9px;color:#000">Terukur: '+_esc(it.psiVal)+' '+_esc(it.psiUnit||'')+'</span>':'')+'</td>';
      if(sec.k2){
        rows+='<tr><td></td><td style="padding:4px 6px">'+lbl+'</td>'+stdCell+
          '<td style="text-align:center">'+_hasilMark(it.r1)+'</td><td style="text-align:center">'+_hasilMark(it.r2)+'</td></tr>';
      } else {
        rows+='<tr><td></td><td style="padding:4px 6px">'+lbl+'</td>'+stdCell+
          '<td style="text-align:center" colspan="2">'+_hasilMark(it.r1)+'</td></tr>';
      }
    });
  });
  var wheelBlocks='';
  Object.keys(fullWheels).forEach(function(si){
    var w=fullWheels[si]; if(!w || !w.rows || !w.rows.length) return;
    var fieldHead=(w.fields||[]).map(function(f){ return '<th style="padding:5px">'+_esc(f.l)+'</th>'; }).join('');
    var wrows='';
    w.rows.forEach(function(row,ri){
      var fieldCells=(w.fields||[]).map(function(f){
        var v=row[f.k];
        return '<td style="text-align:center;padding:4px">'+(v==='ok'?'Baik':v==='ng'?'<b style="color:#000">NG</b>':v==='na'?'N/A':'-')+'</td>';
      }).join('');
      wrows+='<tr><td style="text-align:center;font-weight:700">'+(ri+1)+'</td><td style="text-align:center">'+(row.temp?row.temp+'&deg;C':'-')+'</td>'+fieldCells+'<td style="padding:4px;font-size:10px">'+_esc(row.note||'')+'</td></tr>';
    });
    wheelBlocks+='<div style="page-break-inside:avoid;margin-top:16px">'+
      '<div style="font-size:11px;font-weight:700;color:#000;text-transform:uppercase;margin-bottom:6px">Lembar Pemeriksaan Rangka Bawah &mdash; Detail per Roda</div>'+
      '<table style="width:100%;border-collapse:collapse;font-size:10.5px"><thead><tr style="background:#042C53;color:#fff">'+
        '<th style="padding:5px;width:40px">Roda</th><th style="padding:5px;width:80px">Temp. Bearing</th>'+fieldHead+'<th style="padding:5px">Catatan</th>'+
      '</tr></thead><tbody>'+wrows+'</tbody></table></div>';
  });
  var catatanTemuan=temuan.length?
    temuan.map(function(t,i){ return (i+1)+'. ['+String(t.lv||'minor').toUpperCase()+'] '+_esc(t.lbl)+(t.note?' &mdash; '+_esc(t.note):''); }).join('<br>'):
    'Tidak ada temuan.';
  var saranaUpper=String(entry.sarana||'').toUpperCase();
  return '<!DOCTYPE html><html lang="id"><head><meta charset="UTF-8"><title>Checksheet '+_esc(entry.noKA)+'</title>'+
  '<style>@page{size:A4;margin:14mm}body{font-family:Arial,"Segoe UI",sans-serif;color:#111827;font-size:10.5px;background:#fff;-webkit-print-color-adjust:exact;print-color-adjust:exact}table{border-collapse:collapse;width:100%}td,th{border:1px solid #000}@media print{.np{display:none}}</style></head><body>'+
  '<table style="border:1.3px solid #000;margin-bottom:14px"><tr>'+
    '<td style="width:64px;text-align:center;padding:6px"><img src="'+KEMENHUB_LOGO_B64+'" alt="Kemenhub" style="width:46px;height:46px;object-fit:contain"></td>'+
    '<td style="text-align:center;padding:6px">'+
      '<div style="font-size:12px;font-weight:700">DIREKTORAT SARANA PERKERETAAPIAN</div>'+
      '<div style="font-size:11px;font-weight:700;font-style:italic">CHECKSHEET RAMPCHECK</div>'+
      '<div style="font-size:11px;font-weight:700">'+saranaUpper+'</div>'+
    '</td>'+
    '<td style="width:190px;padding:6px;font-size:9.5px">No. Dokumen: SOP-K4 Tahun 2025<br>Tgl Terbit: 24 Oktober 2025</td>'+
  '</tr></table>'+
  '<table style="border:none;margin-bottom:12px;font-size:10.5px"><tr><td style="border:none;width:160px;padding:2px 0">Nomor Identitas Sarana</td><td style="border:none;width:14px;padding:2px 0">:</td><td style="border:none;font-weight:700;padding:2px 0">'+_esc(entry.noKA)+'</td>'+
    '<td style="border:none;width:90px;padding:2px 0">Depo Induk</td><td style="border:none;width:14px;padding:2px 0">:</td><td style="border:none;font-weight:700;padding:2px 0">'+_esc(entry.dipo||'-')+'</td></tr>'+
    '<tr><td style="border:none;padding:2px 0">Lokasi Pemeriksaan</td><td style="border:none;padding:2px 0">:</td><td style="border:none;font-weight:700;padding:2px 0">'+_esc(entry.lokasi||'-')+'</td><td style="border:none" colspan="3"></td></tr>'+
    '<tr><td style="border:none;padding:2px 0">Tanggal Pemeriksaan</td><td style="border:none;padding:2px 0">:</td><td style="border:none;font-weight:700;padding:2px 0">'+_esc(entry.date)+'</td><td style="border:none" colspan="3"></td></tr></table>'+
  '<table style="font-size:10.5px"><thead><tr style="background:#fff">'+
    '<th style="width:26px;padding:5px">No</th><th style="padding:5px;text-align:left">Item Pemeriksaan Sarana</th><th style="width:150px;padding:5px">Standar</th>'+
    '<th style="width:110px;padding:5px" colspan="2">Hasil</th>'+
  '</tr></thead><tbody>'+rows+'</tbody></table>'+
  wheelBlocks+
  '<div style="margin-top:16px;border:1px solid #CBD5E1;border-radius:6px;padding:10px">'+
    '<div style="font-weight:700;text-decoration:underline;margin-bottom:6px">Catatan Temuan:</div>'+
    '<div style="font-size:10.5px;line-height:1.7">'+catatanTemuan+'</div>'+
  '</div>'+
  '<table style="border:none;margin-top:26px"><tr>'+
    '<td style="border:none;width:33.3%;text-align:center;font-size:10.5px;padding:0 8px">Petugas Pemeriksa<br>Direktorat Jenderal Perkeretaapian<br><br><br><br>'+
      '<span style="border-top:1px solid #111;padding-top:3px;display:inline-block;width:90%">&nbsp;</span><br>NIP. &nbsp;</td>'+
    '<td style="border:none;width:33.3%;text-align:center;font-size:10.5px;padding:0 8px">Petugas Pemeriksa<br>Direktorat Jenderal Perkeretaapian<br><br><br><br>'+
      '<span style="border-top:1px solid #111;padding-top:3px;display:inline-block;width:90%">&nbsp;</span><br>NIP. &nbsp;</td>'+
    '<td style="border:none;width:33.3%;text-align:center;font-size:10.5px;padding:0 8px">Badan Usaha Penyelenggara Sarana<br><br><br><br><br>'+
      '<span style="border-top:1px solid #111;padding-top:3px;display:inline-block;width:90%">&nbsp;</span><br>NIPP. &nbsp;</td>'+
  '</tr></table>'+
  '<div class="np" style="text-align:center;margin-top:20px"><button onclick="window.print()" style="background:#042C53;color:#fff;border:none;padding:10px 24px;border-radius:8px;font-size:13px;font-weight:700;cursor:pointer">Cetak / Simpan PDF</button></div>'+
  '</body></html>';
}

function _serveChecksheetView(kunci){
  var sh=_sheet(SHEET_DETAIL);
  if(sh.getLastRow()<2) return HtmlService.createHtmlOutput('<p>Checksheet tidak ditemukan.</p>');
  var headers=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getValues()[0].map(String);
  var col=function(name){ return headers.indexOf(name); };
  var iKunci=col('Kunci'), iNoKA=col('Nomor Sarana'), iTgl=col('Tanggal'), iSarana=col('Jenis Sarana'),
      iDepo=col('Depo'), iLokasi=col('Lokasi Pemeriksaan'),
      iFC=col('Full Checklist JSON'), iFW=col('Full Wheels JSON'), iTm=col('Temuan JSON');
  var values=sh.getRange(2,1,sh.getLastRow()-1,headers.length).getValues();
  for(var r=0;r<values.length;r++){
    var row=values[r];
    if(iKunci>=0 && String(row[iKunci]||'').trim()===String(kunci).trim()){
      var entry={
        noKA: iNoKA>=0?row[iNoKA]:'', date: iTgl>=0?row[iTgl]:'', sarana: iSarana>=0?row[iSarana]:'',
        dipo: iDepo>=0?row[iDepo]:'', lokasi: iLokasi>=0?row[iLokasi]:'',
        fullChecklist: iFC>=0&&row[iFC]?JSON.parse(row[iFC]):[],
        fullWheels: iFW>=0&&row[iFW]?JSON.parse(row[iFW]):{},
        temuan: iTm>=0&&row[iTm]?JSON.parse(row[iTm]):[]
      };
      var html=_buildChecksheetHtml(entry);
      return HtmlService.createHtmlOutput(html).setTitle('Checksheet '+entry.noKA);
    }
  }
  return HtmlService.createHtmlOutput('<p>Checksheet dengan kunci tersebut tidak ditemukan di database.</p>');
}


/* ============================================================
   AUTENTIKASI AKUN: REGISTER + VERIFIKASI EMAIL + ADMIN APPROVAL
   ============================================================ */
var SHEET_USERS='Users';
var ADMIN_EMAIL_DEFAULT='sandalkulit639@gmail.com';
var USERS_HEADERS=['ID User','Nama','Nomor','NIP','Jabatan','Email','Password Hash','Salt','Email Verified','Status','Role','Email Code','Email Code Expiry','Reset Code','Reset Code Expiry','Created At','Updated At'];

function _ensureUsersHeader(){
  var sh=_sheet(SHEET_USERS);
  if(sh.getLastRow()<1) sh.getRange(1,1,1,USERS_HEADERS.length).setValues([USERS_HEADERS]);
  else {
    var h=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getValues()[0].map(String);
    var miss=USERS_HEADERS.filter(function(x){return h.indexOf(x)<0;});
    if(miss.length) sh.getRange(1,h.length+1,1,miss.length).setValues([miss]);
  }
  return sh;
}
function _adminEmail(){
  return String(PropertiesService.getScriptProperties().getProperty('BTP_ADMIN_EMAIL')||ADMIN_EMAIL_DEFAULT).trim().toLowerCase();
}
function _hashPassword(p,s){
  var b=Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256,String(p||'')+'|'+String(s||''),Utilities.Charset.UTF_8);
  return b.map(function(x){x=x<0?x+256:x;return ('0'+x.toString(16)).slice(-2);}).join('');
}
function _code(){return String(Math.floor(100000+Math.random()*900000));}
function _salt(){return Utilities.getUuid().replace(/-/g,'')+Utilities.getUuid().replace(/-/g,'');}
function _findUser(email){
  email=String(email||'').trim().toLowerCase(); var sh=_ensureUsersHeader(), last=sh.getLastRow();
  if(last<2)return null;
  var h=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),USERS_HEADERS.length)).getValues()[0].map(String);
  var v=sh.getRange(2,1,last-1,h.length).getValues(), ei=h.indexOf('Email');
  for(var i=0;i<v.length;i++) if(String(v[i][ei]||'').trim().toLowerCase()===email){
    var u={row:i+2}; h.forEach(function(k,j){u[k]=v[i][j];}); return u;
  }
  return null;
}
function _setUser(row,data){
  var sh=_ensureUsersHeader(), h=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),USERS_HEADERS.length)).getValues()[0].map(String);
  Object.keys(data).forEach(function(k){var c=h.indexOf(k);if(c>=0)sh.getRange(row,c+1).setValue(data[k]);});
}
function _publicUser(u){
  return {id:u['ID User']||'',nama:u['Nama']||'',nomor:u['Nomor']||'',nip:u['NIP']||'',jabatan:u['Jabatan']||'',
    email:String(u['Email']||'').toLowerCase(),emailVerified:String(u['Email Verified']||'').toUpperCase()==='TRUE',
    status:u['Status']||'',role:u['Role']||'USER',createdAt:u['Created At']||'',updatedAt:u['Updated At']||''};
}
function _sendAuthMail(to,subject,html){
  MailApp.sendEmail({to:to,subject:subject,htmlBody:html,body:html.replace(/<[^>]+>/g,' ')});
}
function _sendCode(to,code,reset){
  _sendAuthMail(to,reset?'Kode Reset Password — BTP Kelas I Medan':'Verifikasi Email — BTP Kelas I Medan',
    '<div style="font-family:Arial,sans-serif;max-width:560px"><h2 style="color:#042C53">BTP Kelas I Medan</h2>'+
    '<p>'+ (reset?'Gunakan kode berikut untuk membuat password baru:':'Gunakan kode berikut untuk memverifikasi alamat email akun Anda:')+
    '</p><div style="font-size:30px;font-weight:800;letter-spacing:8px;color:#185FA5;padding:14px 0">'+code+
    '</div><p>Kode berlaku 15 menit. Jika Anda tidak melakukan permintaan ini, abaikan email ini.</p></div>');
}
function _notifyAdmin(u){
  _sendAuthMail(_adminEmail(),'Pendaftaran akun baru — BTP Kelas I Medan',
    '<div style="font-family:Arial,sans-serif"><h2 style="color:#042C53">Pendaftaran akun baru</h2>'+
    '<p>Akun berikut sudah memverifikasi email dan menunggu persetujuan admin:</p>'+
    '<p><b>Nama:</b> '+_esc(u['Nama'])+'<br><b>Nomor:</b> '+_esc(u['Nomor'])+
    '<br><b>NIP:</b> '+_esc(u['NIP'])+'<br><b>Jabatan:</b> '+_esc(u['Jabatan'])+
    '<br><b>Email:</b> '+_esc(u['Email'])+'</p><p>Buka dashboard &gt; Admin untuk menyetujui atau menolak.</p></div>');
}
function _issueToken(u){
  var t=Utilities.getUuid()+'-'+Utilities.getUuid();
  CacheService.getScriptCache().put('BTP_AUTH_'+t,JSON.stringify({email:String(u['Email']).toLowerCase()}),21600);
  return t;
}
function _session(entry){
  var t=entry&&(entry.authToken||entry.token); if(!t)return null;
  var raw=CacheService.getScriptCache().get('BTP_AUTH_'+t); if(!raw)return null;
  try{var s=JSON.parse(raw),u=_findUser(s.email);if(!u)return null;return {token:t,user:u};}catch(e){return null;}
}
function _requireAuth(entry,admin){
  var s=_session(entry); if(!s)return {ok:false,error:'AUTH_REQUIRED'};
  var st=String(s.user['Status']||'').toUpperCase();
  if(st!=='APPROVED')return {ok:false,error:'ADMIN_APPROVAL_REQUIRED'};
  if(admin && String(s.user['Role']||'USER').toUpperCase()!=='ADMIN')return {ok:false,error:'ADMIN_REQUIRED'};
  return s;
}
function _authErr(code){
  var m={AUTH_REQUIRED:'Silakan login terlebih dahulu.',ADMIN_APPROVAL_REQUIRED:'Akun belum disetujui admin.',ADMIN_REQUIRED:'Akses hanya untuk admin.'};
  return _json({ok:false,error:m[code]||code,code:code});
}
function _handleRegister(e){
  var name=String(e.nama||'').trim(),nomor=String(e.nomor||'').trim(),nip=String(e.nip||'').replace(/\D/g,''),
      jab=String(e.jabatan||'').trim(),email=String(e.email||'').trim().toLowerCase(),pw=String(e.password||''),cf=String(e.confirmPassword||'');
  if(!name||!nomor||!nip||!jab||!email||!pw)return _json({ok:false,error:'Semua field pendaftaran wajib diisi.'});
  if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return _json({ok:false,error:'Format email tidak valid.'});
  if(nip.length!==18)return _json({ok:false,error:'NIP harus 18 digit angka.'});
  if(pw.length<8)return _json({ok:false,error:'Password minimal 8 karakter.'});
  if(pw!==cf)return _json({ok:false,error:'Konfirmasi password tidak sama.'});
  var sh=_ensureUsersHeader(),u=_findUser(email),now=new Date(),code=_code(),salt=_salt();
  if(u){
    var st=String(u['Status']||'').toUpperCase();
    if(st!=='REJECTED' && st!=='EMAIL_UNVERIFIED')return _json({ok:false,error:'Email sudah terdaftar. Silakan login atau gunakan lupa password.'});
    _setUser(u.row,{'Nama':name,'Nomor':nomor,'NIP':nip,'Jabatan':jab,'Password Hash':_hashPassword(pw,salt),'Salt':salt,
      'Email Verified':false,'Status':'EMAIL_UNVERIFIED','Role':email===_adminEmail()?'ADMIN':'USER','Email Code':code,
      'Email Code Expiry':new Date(now.getTime()+900000),'Updated At':now});
  }else{
    var id='USR-'+now.getTime()+'-'+Math.floor(Math.random()*1000);
    sh.appendRow([id,name,nomor,nip,jab,email,_hashPassword(pw,salt),salt,false,'EMAIL_UNVERIFIED',email===_adminEmail()?'ADMIN':'USER',
      code,new Date(now.getTime()+900000),'','',now,now]);
  }
  try{_sendCode(email,code,false);}catch(mailErr){return _json({ok:false,error:'Akun dibuat, tetapi email verifikasi gagal dikirim: '+mailErr});}
  return _json({ok:true,email:email,message:'Kode verifikasi telah dikirim ke email.'});
}
function _handleVerifyEmail(e){
  var email=String(e.email||'').trim().toLowerCase(),code=String(e.code||'').trim(),u=_findUser(email);
  if(!u)return _json({ok:false,error:'Akun tidak ditemukan.'});
  if(String(u['Email Code']||'')!==code || new Date(u['Email Code Expiry']).getTime()<Date.now())
    return _json({ok:false,error:'Kode verifikasi salah atau sudah kedaluwarsa.'});
  var isAdmin=email===_adminEmail();
  var st=isAdmin?'APPROVED':'PENDING_ADMIN';
  _setUser(u.row,{'Email Verified':true,'Status':st,'Role':isAdmin?'ADMIN':'USER','Email Code':'','Email Code Expiry':'','Updated At':new Date()});
  u['Email Verified']=true;u['Status']=st;u['Role']=isAdmin?'ADMIN':'USER';
  if(!isAdmin){try{_notifyAdmin(u);}catch(e){}}
  return _json({ok:true,status:st,user:_publicUser(u),message:isAdmin?'Email terverifikasi. Akun admin aktif.':'Email terverifikasi. Akun menunggu persetujuan admin.'});
}
function _handleLogin(e){
  var email=String(e.email||'').trim().toLowerCase(),pw=String(e.password||''),u=_findUser(email);
  if(!u)return _json({ok:false,error:'Email belum terdaftar.'});
  if(_hashPassword(pw,String(u['Salt']||''))!==String(u['Password Hash']||''))return _json({ok:false,error:'Email atau password tidak sesuai.'});
  if(String(u['Email Verified']||'').toUpperCase()!=='TRUE')return _json({ok:false,error:'Email belum diverifikasi. Gunakan kode verifikasi yang dikirim ke email.',code:'EMAIL_NOT_VERIFIED'});
  var st=String(u['Status']||'').toUpperCase();
  if(st==='REJECTED')return _json({ok:false,error:'Akun ditolak admin. Hubungi admin BTP Medan.',code:'REJECTED'});
  var t=_issueToken(u);return _json({ok:true,token:t,approved:st==='APPROVED',status:st,user:_publicUser(u),adminEmail:_adminEmail()});
}
function _handleResetRequest(e){
  var email=String(e.email||'').trim().toLowerCase(),u=_findUser(email);
  if(!u)return _json({ok:true,message:'Jika email terdaftar, kode reset telah dikirim.'});
  var c=_code(),now=new Date();_setUser(u.row,{'Reset Code':c,'Reset Code Expiry':new Date(now.getTime()+900000),'Updated At':now});
  try{_sendCode(email,c,true);}catch(err){return _json({ok:false,error:'Gagal mengirim email reset: '+err});}
  return _json({ok:true,message:'Kode reset telah dikirim ke email.'});
}
function _handleResetPassword(e){
  var email=String(e.email||'').trim().toLowerCase(),c=String(e.code||'').trim(),pw=String(e.password||''),cf=String(e.confirmPassword||''),u=_findUser(email);
  if(!u||String(u['Reset Code']||'')!==c||new Date(u['Reset Code Expiry']).getTime()<Date.now())return _json({ok:false,error:'Kode reset salah atau sudah kedaluwarsa.'});
  if(pw.length<8)return _json({ok:false,error:'Password baru minimal 8 karakter.'});
  if(pw!==cf)return _json({ok:false,error:'Konfirmasi password tidak sama.'});
  var s=_salt();_setUser(u.row,{'Password Hash':_hashPassword(pw,s),'Salt':s,'Reset Code':'','Reset Code Expiry':'','Updated At':new Date()});
  return _json({ok:true,message:'Password berhasil diubah. Silakan login kembali.'});
}
function _handleAdminList(e){
  var a=_requireAuth(e,true);if(!a.ok)return _authErr(a.error);
  var sh=_ensureUsersHeader(),out=[],last=sh.getLastRow();
  if(last>1){var v=sh.getRange(2,1,last-1,Math.max(sh.getLastColumn(),USERS_HEADERS.length)).getValues();
    v.forEach(function(r){var u={};USERS_HEADERS.forEach(function(h,i){u[h]=r[i];});out.push(_publicUser(u));});}
  return _json({ok:true,users:out,adminEmail:_adminEmail()});
}
function _handleAdminStatus(e){
  var a=_requireAuth(e,true);if(!a.ok)return _authErr(a.error);
  var email=String(e.email||'').trim().toLowerCase(),st=String(e.status||'').toUpperCase(),u=_findUser(email);
  if(!u||['APPROVED','REJECTED'].indexOf(st)<0)return _json({ok:false,error:'Data user/status tidak valid.'});
  if(email===_adminEmail()&&st!=='APPROVED')return _json({ok:false,error:'Akun admin aktif tidak dapat ditolak.'});
  _setUser(u.row,{'Status':st,'Role':st==='APPROVED'?(email===_adminEmail()?'ADMIN':'USER'):'USER','Updated At':new Date()});
  try{_sendAuthMail(email,'Status akun BTP Kelas I Medan','<div style="font-family:Arial"><h2 style="color:#042C53">BTP Kelas I Medan</h2><p>Status akun Anda: <b>'+st+'</b>.</p></div>');}catch(err){}
  return _json({ok:true,message:'Status user diperbarui.'});
}
function _handleAdminEmail(e){
  var a=_requireAuth(e,true);if(!a.ok)return _authErr(a.error);
  var email=String(e.email||'').trim().toLowerCase();if(!/^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(email))return _json({ok:false,error:'Email admin tidak valid.'});
  var old=_adminEmail();if(email===old)return _json({ok:true,adminEmail:email,message:'Email admin tidak berubah.'});
  var u=_findUser(email);if(!u||String(u['Email Verified']||'').toUpperCase()!=='TRUE'||String(u['Status']||'').toUpperCase()!=='APPROVED')
    return _json({ok:false,error:'Email admin baru harus sudah terdaftar, terverifikasi, dan disetujui.'});
  var oldU=_findUser(old);if(oldU)_setUser(oldU.row,{'Role':'USER','Updated At':new Date()});
  _setAdminEmail(email);_setUser(u.row,{'Role':'ADMIN','Status':'APPROVED','Updated At':new Date()});
  return _json({ok:true,adminEmail:email,message:'Akun admin/notifikasi berhasil diganti.'});
}
function _handleAuthMe(e){
  var s=_session(e);if(!s)return _authErr('AUTH_REQUIRED');
  return _json({ok:true,user:_publicUser(s.user),adminEmail:_adminEmail()});
}

/*
 * KOMPATIBILITAS DATABASE v14
 * - BACA/SINKRON: GET /exec?authToken=... -> {ok, headers, rows, temuan, dokumen, sertifikasiLinks, checklistDetail}
 * - TULIS/SIMPAN: POST JSON -> doPost() seperti backend v10/v14 yang sudah terbukti berjalan.
 * - Struktur sheet tetap sama dengan backend v10/v14 agar data lama tidak perlu dipindahkan.
 */
function doGet(e){
  if(e && e.parameter && e.parameter.checksheet){
    return _serveChecksheetView(e.parameter.checksheet);
  }
  if(e && e.parameter && e.parameter.fotoData){
    var fa=_requireAuth({authToken:e.parameter.authToken||''},false);
    if(!fa.ok) return _authErr(fa.error);
    try{
      var f=DriveApp.getFileById(String(e.parameter.fotoData));
      var b=f.getBlob(), bytes=b.getBytes();
      return _json({ok:true,mime:b.getContentType()||'image/jpeg',base64:Utilities.base64Encode(bytes)});
    }catch(fe){ return _json({ok:false,error:'Foto tidak ditemukan.'}); }
  }
  var ga=_requireAuth({authToken:e && e.parameter ? e.parameter.authToken : ''},false);
  if(!ga.ok) return _authErr(ga.error);
  return _handleDashboardData();
}

function _handleDashboardData(){
  try{
    var sh = _sheet(SHEET_REKAP);
    var hRow = _headerRowIndex(sh);
    var lastRow = sh.getLastRow(), lastCol = sh.getLastColumn();
    var rekapOut = {headers:[], rows:[]};
    if(lastRow > hRow){
      var headers = sh.getRange(hRow,1,1,lastCol).getValues()[0].map(function(h){ return String(h).replace(/\n/g,' ').trim(); });
      var values = sh.getRange(hRow+1,1,lastRow-hRow,lastCol).getValues();
      for(var i=0;i<values.length;i++){
        if(values[i].every(function(v){ return v===null||v===''; })) continue;
        var obj = {}; for(var c=0;c<headers.length;c++) obj[headers[c]] = values[i][c];
        rekapOut.rows.push(obj);
      }
      rekapOut.headers = headers;
    }

    var temuanOut = [];
    var shT = _sheet(SHEET_TEMUAN);
    if(shT.getLastRow() > 1){
      var tHeaders = shT.getRange(1,1,1,shT.getLastColumn()).getValues()[0].map(String);
      var tValues = shT.getRange(2,1,shT.getLastRow()-1,shT.getLastColumn()).getValues();
      for(var r=0;r<tValues.length;r++){
        if(tValues[r].every(function(v){ return v===null||v===''; })) continue;
        var tObj={}; for(var c2=0;c2<tHeaders.length;c2++) tObj[tHeaders[c2]]=tValues[r][c2];
        temuanOut.push(tObj);
      }
    }

    var dokumenOut = [];
    var shD = _sheet(SHEET_DOKUMEN);
    if(shD.getLastRow() > 1){
      var dValues = shD.getRange(2,1,shD.getLastRow()-1,DOKUMEN_HEADERS.length).getValues();
      dValues.forEach(function(row){
        if(row.every(function(v){ return v===null||v===''; })) return;
        dokumenOut.push({
          id: row[0], namaFile: row[1], kategori: row[2], ukuran: row[3],
          url: row[4], tanggalUpload: row[5], uploadedBy: row[6]
        });
      });
    }

    var sertifOut = [];
    var shS = _sheet(SHEET_SERTIF);
    if(shS.getLastRow() > 1){
      var sValues = shS.getRange(2,1,shS.getLastRow()-1,SERTIF_HEADERS.length).getValues();
      sValues.forEach(function(row){
        if(row.every(function(v){ return v===null||v===''; })) return;
        sertifOut.push({ id: row[0], url: row[1], updatedAt: row[2] });
      });
    }

    var detailOut = [];
    var shDet = _sheet(SHEET_DETAIL);
    if(shDet.getLastRow() > 1){
      var detHeaders = shDet.getRange(1,1,1,Math.max(shDet.getLastColumn(),1)).getValues()[0].map(String);
      var dCol = function(name){ return detHeaders.indexOf(name); };
      var iNoKA=dCol('Nomor Sarana'), iTgl=dCol('Tanggal'), iSarana=dCol('Jenis Sarana'),
          iUrl=dCol('Link Checksheet'), iFC=dCol('Full Checklist JSON'), iFW=dCol('Full Wheels JSON');
      var detValues = shDet.getRange(2,1,shDet.getLastRow()-1,detHeaders.length).getValues();
      detValues.forEach(function(row){
        if(row.every(function(v){ return v===null||v===''; })) return;
        detailOut.push({
          noKA: iNoKA>=0?row[iNoKA]:'', tanggal: iTgl>=0?row[iTgl]:'', sarana: iSarana>=0?row[iSarana]:'',
          checksheetUrl: iUrl>=0?row[iUrl]:'', fullChecklistJson: iFC>=0?row[iFC]:'', fullWheelsJson: iFW>=0?row[iFW]:''
        });
      });
    }

    return _json({ok:true, sheet:SHEET_REKAP, headers:rekapOut.headers, rows:rekapOut.rows,
      temuan:temuanOut, dokumen:dokumenOut, sertifikasiLinks:sertifOut, checklistDetail:detailOut});
  } catch(err){ return _json({ok:false, error:String(err)}); }
}

function doPost(e){
  try{
    if(!e || !e.postData || !e.postData.contents) return _json({ok:false,error:'Tidak ada data terkirim'});
    var entry; try{entry=JSON.parse(e.postData.contents);}catch(pe){return _json({ok:false,error:'JSON tidak valid: '+pe});}
    if(entry.action==='auth_register') return _handleRegister(entry);
    if(entry.action==='auth_verify_email') return _handleVerifyEmail(entry);
    if(entry.action==='auth_login') return _handleLogin(entry);
    if(entry.action==='auth_reset_request') return _handleResetRequest(entry);
    if(entry.action==='auth_reset_password') return _handleResetPassword(entry);
    if(entry.action==='auth_me') return _handleAuthMe(entry);
    if(entry.action==='get_data'){ var gd=_requireAuth(entry,false); if(!gd.ok)return _authErr(gd.error); return _handleDashboardData(); }
    if(entry.action==='admin_list_users') return _handleAdminList(entry);
    if(entry.action==='admin_set_status') return _handleAdminStatus(entry);
    if(entry.action==='admin_set_email') return _handleAdminEmail(entry);
    if(entry.action==='update_temuan'){
      var au=_requireAuth(entry,false); if(!au.ok)return _authErr(au.error); entry.petugas=entry.petugas||au.user['Nama']; entry.nip=entry.nip||au.user['NIP'];
      return _handleUpdateTemuan(entry);
    }
    if(entry.action==='upload_dokumen') return _handleUploadDokumen(entry);
    if(entry.action==='delete_dokumen') return _handleDeleteDokumen(entry);
    if(entry.action==='update_kategori_dokumen') return _handleUpdateKategoriDokumen(entry);
    if(entry.action==='save_sertif_links') return _handleSaveSertifLinks(entry);
    var ar=_requireAuth(entry,false); if(!ar.ok)return _authErr(ar.error);
    entry.petugas=entry.petugas||ar.user['Nama']; entry.nip=entry.nip||ar.user['NIP'];
    return _handleSaveRampcheck(entry);
  }catch(err){return _json({ok:false,error:String(err)});}
}

function _handleSaveSertifLinks(entry){
  var adm=_requireAuth(entry,true); if(!adm.ok) return _authErr(adm.error);
  var links = entry.links;
  if(!links || !links.length) return _json({ok:false, error:'Tidak ada link dikirim'});
  var sh = _ensureSertifHeader();
  var now = new Date();
  links.forEach(function(l){
    var id = String(l.id||'').trim();
    var url = String(l.url||'').trim();
    if(!id) return;
    _upsertByKey(sh, 'ID Layanan', id, {'ID Layanan':id, 'URL':url, 'Tanggal Update':now});
  });
  return _json({ok:true, message:'Link sertifikasi tersimpan'});
}

function _handleUploadDokumen(entry){
  var adm=_requireAuth(entry,true); if(!adm.ok) return _authErr(adm.error);
  var namaFile = String(entry.namaFile||'').trim();
  var kategori = String(entry.kategori||'lainnya').trim();
  var fileBase64 = entry.fileBase64;
  var ukuran = entry.ukuran || 0;
  var uploadedBy = String(entry.uploadedBy||'').trim();
  if(!namaFile || !fileBase64) return _json({ok:false, error:'Nama file dan data file wajib diisi'});
  var uploaded;
  try{ uploaded = _uploadFileToDrive(fileBase64, namaFile); }
  catch(e){ return _json({ok:false, error:'Gagal mengunggah ke Google Drive: '+e}); }
  var sh = _ensureDokumenHeader();
  var now = new Date();
  var idDokumen = 'DOC-'+now.getTime()+'-'+Math.floor(Math.random()*1000);
  sh.appendRow([idDokumen, namaFile, kategori, ukuran, uploaded.url, now, uploadedBy]);
  return _json({ok:true, message:'Dokumen tersimpan', id:idDokumen, url:uploaded.url, tanggalUpload:now});
}

function _handleDeleteDokumen(entry){
  var adm=_requireAuth(entry,true); if(!adm.ok) return _authErr(adm.error);
  var idDokumen = String(entry.idDokumen||'').trim();
  if(!idDokumen) return _json({ok:false, error:'ID dokumen tidak ada'});
  var sh = _ensureDokumenHeader();
  var lastRow = sh.getLastRow();
  if(lastRow > 1){
    var idVals = sh.getRange(2,1,lastRow-1,1).getValues();
    for(var r=0;r<idVals.length;r++){
      if(String(idVals[r][0]||'').trim() === idDokumen){
        var rowNum = r+2;
        var url = sh.getRange(rowNum,5).getValue();
        try{
          var m = String(url).match(/\/d\/([a-zA-Z0-9_-]+)/);
          if(m) DriveApp.getFileById(m[1]).setTrashed(true);
        } catch(e){}
        sh.deleteRow(rowNum);
        return _json({ok:true, message:'Dokumen dihapus'});
      }
    }
  }
  return _json({ok:false, error:'Dokumen dengan ID tersebut tidak ditemukan'});
}

function _handleUpdateKategoriDokumen(entry){
  var adm=_requireAuth(entry,true); if(!adm.ok) return _authErr(adm.error);
  var idDokumen = String(entry.idDokumen||'').trim();
  var kategori = String(entry.kategori||'').trim();
  if(!idDokumen || !kategori) return _json({ok:false, error:'Data tidak lengkap'});
  var sh = _ensureDokumenHeader();
  var lastRow = sh.getLastRow();
  if(lastRow > 1){
    var idVals = sh.getRange(2,1,lastRow-1,1).getValues();
    for(var r=0;r<idVals.length;r++){
      if(String(idVals[r][0]||'').trim() === idDokumen){
        sh.getRange(r+2,3).setValue(kategori);
        return _json({ok:true, message:'Kategori diperbarui'});
      }
    }
  }
  return _json({ok:false, error:'Dokumen dengan ID tersebut tidak ditemukan'});
}

function _handleSaveRampcheck(entry){
  var noKA = String(entry.noKA||'').trim();
  var date = String(entry.date||'').trim();
  if(!noKA||!date) return _json({ok:false, error:'Nomor Sarana dan Tanggal wajib diisi'});

  var sarana = String(entry.sarana||'').trim();
  var nM=_countLv(entry.temuan,'mayor'), nMn=_countLv(entry.temuan,'minor');
  var status=_statusFromTemuan(entry.temuan), now=new Date();

  var targetSheetName = (TYPE_SHEETS.indexOf(sarana)>=0) ? sarana : SHEET_FALLBACK;
  var shType=_sheet(targetSheetName);
  var flat={
    'Nomor Sarana':noKA, 'Tanggal':date, 'Jenis Sarana':sarana||targetSheetName,
    'Depo':entry.dipo||'', 'Lokasi Pemeriksaan':entry.lokasi||'',
    'Petugas Pemeriksa':entry.petugas||'', 'NIP Petugas':entry.nip||'',
    'Status Hasil':status, 'Total Mayor':nM, 'Total Minor':nMn,
    'Waktu Kirim':now
  };
  if(entry.checklistData && typeof entry.checklistData==='object'){
    for(var k in entry.checklistData) if(entry.checklistData.hasOwnProperty(k)) flat[k]=entry.checklistData[k];
  }
  _appendFlexibleRow(shType, flat, ['Nomor Sarana','Tanggal','Jenis Sarana','Depo','Lokasi Pemeriksaan',
    'Petugas Pemeriksa','NIP Petugas','Status Hasil','Total Mayor','Total Minor','Waktu Kirim']);

  var shRekap=_sheet(SHEET_REKAP);
  var rekapData={
    'NOMOR SARANA':noKA, 'DEPO':entry.dipo||'', 'STATUS':'AKTIF',
    'JENIS SARANA':sarana, 'SERTIFIKASI':'BERLAKU',
    'RAMPCHECK\nDONE':'SUDAH DI RAMPCHECK', 'TGL RAMPCHECK':date,
    'PELAKSANA\nRAMPCHECK':entry.petugas||'', 'KEPEMILIKAN\nDAOP':entry.lokasi||'',
    'TOTAL\nTEMUAN':nM+nMn, 'STATUS\nHASIL':status
  };
  _upsertByKey(shRekap, 'NOMOR SARANA', noKA, rekapData);

  var touchedTemuan=false;
  if(entry.temuan && entry.temuan.length){
    var shTemuan=_ensureTemuanHeader();
    entry.temuan.forEach(function(t, ti){
      var fotoUrls = _uploadPhotosToDrive(t.foto||[], noKA.replace(/[^A-Za-z0-9]+/g,''));
      var idTemuan = t.idTemuan || (noKA.replace(/[^A-Za-z0-9]+/g,'')+'-'+date+'-'+ti+'-'+now.getTime());
      shTemuan.appendRow([
        idTemuan, noKA, date, sarana, String(t.lv||'').toUpperCase(), t.komponen||'', t.lbl||'',
        t.std||'', t.note||(t.psiVal?('Nilai terukur: '+t.psiVal):''),
        fotoUrls.join('\n'), 'Baru', '', '', now
      ]);
    });
    touchedTemuan=true;
  }

  var touchedDetail=false;
  if(entry.fullChecklist && entry.fullChecklist.length){
    var shDetail=_ensureDetailHeader();
    var kunci = noKA+'||'+date;
    var checksheetUrl = ScriptApp.getService().getUrl()+'?checksheet='+encodeURIComponent(kunci);
    _upsertByKey(shDetail, 'Kunci', kunci, {
      'Kunci': kunci, 'Nomor Sarana': noKA, 'Tanggal': date, 'Jenis Sarana': sarana,
      'Depo': entry.dipo||'', 'Lokasi Pemeriksaan': entry.lokasi||'',
      'Link Checksheet': checksheetUrl,
      'Full Checklist JSON': JSON.stringify(entry.fullChecklist),
      'Full Wheels JSON': JSON.stringify(entry.fullWheels||{}),
      'Temuan JSON': JSON.stringify(entry.temuan||[]),
      'Waktu Kirim': now
    });
    touchedDetail=true;
  }

  return _json({ok:true, message:'Tersimpan', sheets:[targetSheetName, SHEET_REKAP]
    .concat(touchedTemuan?[SHEET_TEMUAN]:[]).concat(touchedDetail?[SHEET_DETAIL]:[])});
}

function _handleUpdateTemuan(entry){
  var idTemuan=String(entry.idTemuan||'').trim();
  if(!idTemuan) return _json({ok:false, error:'ID temuan tidak ada'});
  var sh=_ensureTemuanHeader();
  var headers=sh.getRange(1,1,1,sh.getLastColumn()).getValues()[0];
  var idCol=headers.indexOf('ID Temuan');
  var lastRow=sh.getLastRow();
  var targetRow=-1;
  if(lastRow>1){
    var idVals=sh.getRange(2,idCol+1,lastRow-1,1).getValues();
    for(var r=0;r<idVals.length;r++){
      if(String(idVals[r][0]||'').trim()===idTemuan){ targetRow=r+2; break; }
    }
  }
  if(targetRow===-1) return _json({ok:false, error:'Temuan dengan ID tersebut tidak ditemukan di database'});

  var now=new Date();
  var noKA=String(entry.noKA||'').trim();
  var fotoUrls=_uploadPhotosToDrive(entry.foto||[], noKA.replace(/[^A-Za-z0-9]+/g,'')+'-update');

  var colOf=function(name){ return headers.indexOf(name)+1; };
  var oldRiwayat = sh.getRange(targetRow, colOf('Riwayat Update')).getValue() || '';
  var tanggalTampil = Utilities.formatDate(now, Session.getScriptTimeZone()||'GMT+7', 'dd/MM/yyyy HH:mm');
  var petugasTxt = entry.petugas ? (' oleh '+entry.petugas+(entry.nip?' (NIP '+entry.nip+')':'')) : '';
  var newEntryTxt = '['+tanggalTampil+'] ('+(entry.status||'Update')+')'+petugasTxt+': '+(entry.catatan||'-');
  var newRiwayat = oldRiwayat ? (oldRiwayat+'\n'+newEntryTxt) : newEntryTxt;

  sh.getRange(targetRow, colOf('Riwayat Update')).setValue(newRiwayat);
  sh.getRange(targetRow, colOf('Tanggal Update Terakhir')).setValue(now);
  if(entry.status) sh.getRange(targetRow, colOf('Status Temuan')).setValue(entry.status);
  if(fotoUrls.length){
    var oldFoto = sh.getRange(targetRow, colOf('Foto Bukti')).getValue() || '';
    sh.getRange(targetRow, colOf('Foto Bukti')).setValue(oldFoto ? (oldFoto+'\n'+fotoUrls.join('\n')) : fotoUrls.join('\n'));
  }

  return _json({ok:true, message:'Update temuan tersimpan', sheets:[SHEET_TEMUAN]});
}

function _ensureTemuanHeader(){
  var sh=_sheet(SHEET_TEMUAN);
  if(sh.getLastRow()<1){
    sh.getRange(1,1,1,TEMUAN_HEADERS.length).setValues([TEMUAN_HEADERS]);
    return sh;
  }
  var headers=sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getValues()[0].map(String);
  var missing=TEMUAN_HEADERS.filter(function(h){ return headers.indexOf(h)===-1; });
  if(missing.length){ sh.getRange(1, headers.length+1, 1, missing.length).setValues([missing]); }
  return sh;
}

function _appendFlexibleRow(sh, data, fixedOrder){
  var lastRow=sh.getLastRow();
  var headers = lastRow>=1 ? sh.getRange(1,1,1,Math.max(sh.getLastColumn(),1)).getValues()[0].map(String) : [];
  if(lastRow<1){
    headers = fixedOrder.slice();
    sh.getRange(1,1,1,headers.length).setValues([headers]);
  }
  var newCols=[];
  Object.keys(data).forEach(function(k){ if(headers.indexOf(k)===-1) newCols.push(k); });
  if(newCols.length){
    headers = headers.concat(newCols);
    sh.getRange(1, headers.length-newCols.length+1, 1, newCols.length).setValues([newCols]);
  }
  var targetRow = sh.getLastRow()+1;
  var rowArr = headers.map(function(h){ return data.hasOwnProperty(h) ? data[h] : ''; });
  sh.getRange(targetRow,1,1,rowArr.length).setValues([rowArr]);
}

function _upsertByKey(sh, keyHeader, keyValue, data){
  var hRow=_headerRowIndex(sh);
  var lastCol=Math.max(sh.getLastColumn(),1);
  var headersRaw=sh.getRange(hRow,1,1,lastCol).getValues()[0];
  function norm(s){ return String(s||'').replace(/\n/g,' ').replace(/\s+/g,' ').trim().toUpperCase(); }
  var headers=headersRaw.map(norm);
  var keyCol=headers.indexOf(norm(keyHeader)); if(keyCol===-1) keyCol=0;

  var lastRow=sh.getLastRow(), targetRow=-1;
  if(lastRow>hRow){
    var keyVals=sh.getRange(hRow+1,keyCol+1,lastRow-hRow,1).getValues();
    for(var r=0;r<keyVals.length;r++){
      if(String(keyVals[r][0]||'').trim().toUpperCase()===String(keyValue).trim().toUpperCase()){ targetRow=hRow+1+r; break; }
    }
  }
  if(targetRow===-1) targetRow=Math.max(sh.getLastRow()+1, hRow+1);

  var byHeaderExact={}; headersRaw.forEach(function(h,i){ byHeaderExact[String(h)]=i; });
  for(var k in data){
    if(!data.hasOwnProperty(k)) continue;
    var col = (byHeaderExact.hasOwnProperty(k)) ? byHeaderExact[k] : headers.indexOf(norm(k));
    if(col===-1||col===undefined) continue;
    sh.getRange(targetRow, col+1).setValue(data[k]);
  }
}

function _countLv(temuan,lv){ if(!temuan||!temuan.length) return 0; return temuan.filter(function(t){return t.lv===lv;}).length; }
function _statusFromTemuan(temuan){
  var nM=_countLv(temuan,'mayor'), nMn=_countLv(temuan,'minor');
  return nM>0?'MAYOR':nMn>0?'MINOR':'AMAN';
}
